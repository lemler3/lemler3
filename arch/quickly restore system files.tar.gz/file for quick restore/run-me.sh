#!/bin/bash
# flat mouse acceleration
sudo mv -v -Z  '50-mouse-acceleration.conf' '/etc/X11/xorg.conf.d/50-mouse-acceleration.conf'
sudo mv -v -Z  'makepkg.conf' '/etc/makepkg.conf'
sudo mv -v -Z  'nanorc' '/etc/nanorc'
sudo mv -v -Z  'pacman.conf' '/etc/pacman.conf'